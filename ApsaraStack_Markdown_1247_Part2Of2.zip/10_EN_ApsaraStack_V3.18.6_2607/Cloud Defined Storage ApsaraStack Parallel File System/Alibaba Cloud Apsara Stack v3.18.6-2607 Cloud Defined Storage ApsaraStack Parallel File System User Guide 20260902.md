---
title: "Alibaba Cloud Apsara Stack v3.18.6-2607 Cloud Defined Storage ApsaraStack Parallel File System User Guide 20260902"
product_version: "V3.18.6_2607"
doc_version: "20260902"
pdf_pages: 20
source_pdf: "a3584514e01046cd_Alibaba Cloud Apsara Stack v3.18.6-2607 Cloud Defined Storage ApsaraStack Parallel File System User "
source_url: "https://apsarastackdocument.oss-cn-hangzhou.aliyuncs.com/%E5%9B%BD%E9%99%85%E7%89%88%E6%96%87%E6%A1%A3/3816%202607/pdf%203/CDS/Alibaba%20Cloud%20Apsara%20Stack%20v3.18.6-2607%20Cloud%20Defined%20Storage%20ApsaraStack%20Parallel%20File%20System%20User%20Guide%2020260902.pdf"
converter: pdf2md (PyMuPDF line classifier, toc+numbered-headings+note-quotes+edge-junk)
---

# Alibaba Cloud Apsara Stack v3.18.6-2607 Cloud Defined Storage ApsaraStack Parallel File System User Guide 20260902

## Table of Contents

- 1 What is APFS?
- 2 Getting Started
  - 2.1 Log on to the File Storage APFS console
  - 2.2 Create an APFS file system
  - 2.3 Limitations
- 3 APFS list
  - 3.1 Manage APFS file systems
  - 3.2 Scale up an APFS file system
  - 3.3 Resource monitoring
  - 3.4 Data flow
    - 3.4.1 Backup plans
    - 3.4.2 Replica management
    - 3.4.3 Import jobs
- 4 FAQ
  - 4.1 No inventory for sales

## 1 What is APFS?

**Overview**

ApsaraStack Parallel File System (APFS) is a cloud-defined, distributed parallel file system service. APFS delivers high performance that is required for large-scale parallel training in intelligent computing scenarios and offers features such as intelligent data management, reliable data security, flexible deployment, and elastic scaling of resources. AFPS applies to scenarios where Hygon DCUs, Ascend GPUs, and Hygon storage cluster are used.

## 2 Getting Started

### 2.1 Log on to the File Storage APFS console

**APFS console**

**Prerequisites**

You have obtained the service domain name for the Apsara Uni-manager Management Console from the deployment personnel. Use the Google Chrome browser.

**Procedure**

1. In the address bar of your browser, enter the service domain name for the Apsara Uni-
manager Management Console and press Enter.

> **Note:** You can click the current language in the upper-right corner to switch to another language.

2. Enter your username and password.

> **Note:** You can obtain the username and logon password from an operations administrator.
> If this is your first time logging on to the Apsara Uni-manager Management Console, you must change your password. For security, the password must be 10 to 32 characters long and contain uppercase letters, lowercase letters, digits, and special characters. The supported special characters are: !, @, #, $, and %.

3. Select **I Have Read And Agree To The Product Service Agreement, Privacy**
**Agreement, And User Agreement**.

**Note**

The link text on the logon page is the title of the agreement document. You can click the link to view the details of the agreement.

> The **Product Service Agreement**, **Privacy Agreement**, and **User** **Agreement** are displayed only if they have been published. If none of these agreements are published, you can skip this step.

4. Click **Account Logon** or **Authorized Logon**.

> **Note:** The Authorized Logon button is displayed only if the global IdP setting for third-party authentication is enabled. This display name can be customized. The default name is "Authorized Logon".

5. If multi-factor authentication (MFA) is enabled for your account, follow the steps for one of
the following scenarios:

> **Note:** When you log on from the Internet, multi-factor authentication (MFA) is mandatory by default.

**First logon after MFA is enabled**

a. After you log on with your username and password, the Bind Virtual MFA Device page appears. b. On the Bind Virtual MFA Device page, follow the on-screen instructions to bind a virtual MFA device. c. You have logged in to the console.

**MFA is already enabled and a device is bound**

Enter the six-digit MFA code and click **Authenticate**.
6. From the product drop-down menu, select **Products > Storage > File Storage APFS** to
open the File Storage APFS console.

### 2.2 Create an APFS file system

This topic shows you how to create a file system in the APFS console.

**Procedure**

1. Log on to the File Storage APFS console.
2. On the **APFS File Systems** page, click **Create File System**.
3. On the **Create File System** page, configure the parameters.
After you configure the parameters, a summary of your configuration appears in the rightside panel. The following table describes the parameters.

| Configuration |   | Description |
|---|---|---|
| Billing Configurati on | Billing Method | Only the pay-as-you-go billing method is supported. With this method, you pay for the resources you use. It is ideal for fluctuating business demands, as it lets you use resources flexibly and helps you avoid waste. Note This option is displayed only if your administrator has configured billing rules in the Operations Center. For more information about billing rules, see the Operations Center > Service Operations > Service Pricing > Billing Rules section in the Unified Cloud Management Platform User Guide within the Apsara Stack documentation. |
| Basic Information | Organization/R esource Set | Select the organization and resource set for the file system. |
|   | Region/Availab ility Zone | Select the region and availability zone for the file system. |
|   | File System Type | The default value is BMEFS. |
|   | Cluster | Specify the cluster for the file system. |
|   | Specification | Only Performance NAS File System is supported. |
|   | Capacity (TiB) | Set the capacity for the file system. The value must be greater than or equal to 1 TiB and less than or equal to the total available capacity. |

| ud Defined Sto | ApsaraStack Parallel File System rage User Guide·Getting Starte |   |
|---|---|---|
| Details |   |   |
|   | Name | Enter a name for the file system. The name must be 2 to 128 characters in length. It must start with a letter and can contain digits, underscores ( ), hyphens (- _ ), and colons (:). Chinese characters are not supported. The name cannot start with http:// or https:// . |

4. Optional. If you want to set quotas for the resources of a service, click **Quota**
**Management** on the right side of the page to go to the **Quotas** page. For more
information, see the **Quota management** topic in User Guide - Apsara Uni-manager Mana gement Console.
5. Click **Confirm Order**.
6. After the file system is created, you can view its status, specifications, and capacity on the
APFS File Systems page. To mount the file system, go to the BMCP console. For detailed instructions, see the **Clusters and nodes** section in the **BMCP User Guide**.

### 2.3 Limitations

This topic describes the limitations of the APFS file system. Only performance file systems are supported, with a maximum total capacity of 25 PiB. You can mount the file system to BMCP compute clusters from the BMCP console and to BCI containers from the BCI console. The system automatically creates a default mount target. You cannot create additional mount targets. You can expand the file system only when there is no active data I/O. Cluster scale-in is not supported.

## 3 APFS list

### 3.1 Manage APFS file systems

**View an APFS file system**

**Prerequisites**

An ApsaraStack Parallel File System (APFS) file system is created. For more information, see Create an APFS file system.

**Procedure**

1. Log on to the APFS console.
2. On the APFS page, you can search for a file system by **File System ID** or **File System**
**Name**.
3. On the APFS page, find the file system that you want to view, and click the
icon in the
**Monitoring** column to view monitoring metrics such as capacity, bandwidth, and
read/write IOPS of the file system.
4. On the APFS page, click a file system ID or click **Details** in the **Actions** column to view the
basic information about the file system.
5. On the **Basic Information** tab, you can view the ID, status, specifications, and capacity of
the file system.

**Delete an APFS file system**

**Prerequisites**

Before you delete an APFS file system, the file system is unmounted from the mount target. Deleted APFS file systems cannot be restored. Make sure that you back up the data stored in an APFS file system before you delete it. After you delete an APFS file system, resources of the file system are not immediately released. The disk space occupied by the file system is released seven days later.

**Procedure**

1. Log on to the APFS console.
2. On the APFS page, find the file system that you want to delete and click **Delete** in the
**Actions** column.
3. In the dialog box that appears, click **OK**.

**Modify the description of an APFS file system**

1. On the APFS page, find the file system for which you want to modify the description, move
the pointer over the **File System ID/Name** column, and click the icon.
2. In the dialog box that appears, enter a new description.
3. Then, click **OK**.

> **Note:** The description of the file system must be 2 to 128 characters in length and can contain letters, digits, underscores (_), hyphens (-), and colons (:). It must start with a letter. It cannot start with `http://` or `https://` .

### 3.2 Scale up an APFS file system

**Prerequisites**

1. An ApsaraStack Parallel File System (APFS) file system is created. For more information, see
Create an APFS file system.
2. No data is being read from or written to the APFS file system.

**Procedure**

1. Log in to the APFS console.
2. On the APFS page, find the file system that you want to scale up and click **Scale Up** in the
Actions column.
3. On the File system expansion page, specify a value for the **New Total Capacity (TiB)**
parameter.

> **Note:** The new total capacity cannot be less than the current total capacity and cannot exceed the maximum total capacity of the cluster.

4. Click **Confirm Order** to complete the scale-up.

### 3.3 Resource monitoring

This topic describes how to view monitoring metrics and create alert rules for ApsaraStack Parallel File System (APFS) resources.

**Prerequisites**

An APFS file system is created. For more information, see Create an APFS file system.

**Procedure**

1. Log on to the APFS console.
2. Click **APFS**, and then click the ID or name of a file system or click **Details** in the Actions
column to go to the File System Details page.
3. On the File System Details page, click the **Monitoring** tab in the upper-left corner to view
monitoring metrics such as capacity, bandwidth, and read/write IOPS of the file system.
4. You can also click the
icon in the upper-right corner of the chart to create an alert rule. For more information, see the **Create an alert rule** topic in **CloudMonitor User Guide**.
5. After an alert rule is created, you can choose **Products > Migration and O&M**
**Management > CloudMonitor** in the top navigation bar and click **Alert Service** in the
left-side navigation pane to view and manage the alert rule.

### 3.4 Data flow

You can efficiently migrate data between ApsaraStack Parallel File System (APFS) and Object Storage Service (OSS). APFS also provides the data backup and import features to help you manage the lifecycle of data assets, optimize costs, and quickly import data in highperformance computing scenarios. Data backup: You can create backup plans to automatically back up data from APFS file systems to OSS at the scheduled time. This feature is applicable to the following scenarios: Data backup and disaster recovery: You can synchronize data replicas from APFS to OSS by creating a cross-storage medium backup policy, which improves data security. Storage cost optimization: APFS can identify and migrate infrequently accessed data to OSS in order to reduce the storage costs and conduct tiered data management. Data import: You can create import jobs to quickly import data from OSS to APFS. This feature is applicable to the following scenarios: Data migration from on-premises environments to the cloud: OSS supports multiple data importing methods. You can use OSS to quickly import data from on-premises environments or other systems to APFS. Acceleration of training based on AI and big data: The historical data stored in OSS may consistently grow over time. You can batch import the volumetric data from OSS to highperformance APFS file systems. This way, the data can be accessed with a low latency and a high throughput in scenarios demanding an extremely high I/O throughput, such as AI model training and high-performance computing.

#### 3.4.1 Backup plans

You can create backup plans in the ApsaraStack Parallel File System (APFS) console to replicate data from APFS to Object Storage Service (OSS).

**Create a backup plan**

**Limits**

For the same user and region, you can create only one backup plan for each file system. The names of backup plans for the same user and region must be unique. The minimum backup interval is 24 hours. If the source file system is in the Deleting, Deleted, Stopping, or Stopped state, the backup plan is automatically suspended.

**Prerequisites**

An APFS file system is created and is in the Available state. For more information, see Create an APFS file system. An OSS bucket is created.

**Procedure**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. On the **Backup Plan** tab, click **Create Backup Plan** and configure the following
parameters.

| Section | Parameter | Description |
|---|---|---|
| Basic Informatio n | Schedule Name | Enter a name for the backup plan. |
|   | Description | Enter the description of the backup plan. |
| Data Source Configura tion | Source File System | Select the APFS file system for which you want to create a backup plan. |
|   | Source Path | Enter the path of the files that you want to back up. Example: /source/path. |
|   | OSS Bucket | Select the OSS bucket to which data is backed up from the drop-down list. |
|   | Destination Storage Location | Enter the path to which data is backed up in the OSS bucket. Example: oss-bucket-name/oss-path. |
| Schedulin g Configura tion | Cron Expression | Enter a cron expression to specify the time when the backup plan is triggered. For example, 0 0 12 * * ? indicates that the backup plan is triggered at 12:00 every day. Important The backup interval must be at least one day. |
|   | Migration Speed | Express: The migration speed is unlimited. Standard: The maximum migration speed is 200 MB/s. Basic: The migration bandwidth occupied by an APFS node does not exceed 50% of the total bandwidth. |
|   | Excluded Paths | Enter the paths of files that you do not want to back up in the source file system. All files in the specified paths are not replicated to the OSS bucket. Separate multiple paths with commas (,). Example: /tmp,/logs,/cache. |
|   | Filename Matching Pattern | Enter the extensions of files that you want to back up. Only matching files are backed up. Separate multiple file extensions with commas (,). Example: *.log,*.tmp,*.bak. |

|   | File Size Threshold | Specify the file size threshold. Format: integer + unit. You can enter a single value or a value range. If you specify a range, separate the two values with a comma (,). Supported units: B (bytes), K (KiB), M (MiB), G (GiB), and T (TiB). The units are not case-sensitive. If you enter a single value, only files whose sizes equal or exceed the threshold are backed up. For example, if you specify 1G, only files whose sizes are 1 GiB or larger are backed up. If you enter a value range, the minimum value must be smaller than the maximum value. For example, if you specify 1G,2G, only files whose sizes range from 1 GiB to 2 GiB are backed up. |
|---|---|---|
| Advanced Configura tion |   |   |
|   | File Operation Time Threshold | Specify the file modification time threshold. Format: integer + unit. You can enter a single value or a value range. If you specify a range, separate the two values with a comma (,). Supported units: ms (milliseconds), s (seconds), m (minutes), h (hours), d (days), w (weeks), M (months, which are counted based on 30 days), and y (years, which are counted based on 365 days). Take note that m (lowercase) stands for minutes and M (uppercase) stands for months. If you enter a single value, only files with a time gap longer than the specified value are backed up. The time gap refers to the time span between the time when the file was last modified (such as mtime) and the current system time. For example, if you specify 3d, only files that were modified three days ago or earlier are backed up. If you enter a value range, the minimum value must be smaller than the maximum value. For example, if you specify 1d,5d, only files with a time gap ranging from one day to five days are backed up. Important Take note that m (lowercase) stands for minutes and M (uppercase) stands for months. A value range consists of only the minimum value and the maximum value. The minimum value of a value range must be smaller than the maximum value. Decimals are not supported. |

|   | Maximum Capacity Limit (GiB) | The total OSS storage used to store the replicas created by the backup plan. Unit: GiB. Default value: 1024. Note When the specified OSS storage is exhausted, the backup plan is suspended. |
|---|---|---|

4. Click **Submit**.

**View a backup plan**

**Prerequisites**

A backup plan is created.

**Procedure**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. On the **Backup Plan** tab, you can view the details of each backup plan in the list. Click the
ID of a backup plan in the **Plan ID/Name** column to view the details of the backup plan. Basic Information: displays the plan ID, plan name, source file system, source path, cron expression, migration speed, and status. Execution Details: displays the most recent time when the backup plan was successfully executed, the number of consecutive failures, and the time when the most recent failure occurred. Storage Information: displays the total storage capacity, source path, and destination path of the backup plan.

**Modify a backup plan**

**Prerequisites**

A backup plan is created.

**Procedure**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. On the **Backup Plan** tab, click **Modify** in the Actions column of the desired backup plan.
4. On the **Edit Backup Plan** page, you can modify the plan name, status (enabled or
disabled), cron expression, and migration speed.
5. Click **Submit**.

**Delete a backup plan**

**Procedure**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. On the **Backup Plan** tab, click **Delete** in the Actions column of the desired backup plan.
4. In the message that appears, confirm the information and click **OK**.

#### 3.4.2 Replica management

The replica management feature of ApsaraStack Parallel File System (APFS) allows you to manually create replica tasks, cancel replica tasks, and delete replicas.

**Limits**

Each user can run at most two replica tasks concurrently. At most five replica tasks can be run concurrently on a global scale. Within the same backup plan, only one replica can be synchronized at a time. The storage capacity of a backup plan is limited. The default is 1024 GiB. The total size of all healthy replicas must not exceed the storage capacity. You can cancel only replica tasks in the Synchronizing state. You can create replicas only when the corresponding backup plan is enabled. If a backup plan fails for a certain number of times, the backup plan enters the SUSPENDED state. In this case, manual intervention is needed.

**Manage replicas**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. Click the **Replica Management** tab to manage replica tasks.

| Operation | Description |
|---|---|
| View replica tasks | Click the ID of a replica task in theR eplica ID/Name column to view its details. Basic Information: displays the replica task ID, backup plan ID, source file system ID, status, creation time, and end time. Progress Information: displays the synchronization progress (%), transfer speed, number of transferred files, and size (bytes). Storage Information: displays the source path, destination path, and total size (bytes). |
| Cancel replica tasks | You can cancel a replica task in the Synchronizing state. Click Cancel Task in the Actions column of the desired task. In the message that appears, confirm the information and click OK. |
| Delete replica tasks | You can delete replica tasks that are no longer needed. Note Files that have already been replicated to the destination Object Storage Service (OSS) bucket are not deleted. Click Delete Replica in the Actions column of the desired task. In the message that appears, confirm the information and click OK. |

**Manually create a replica task**

A backup plan is created. For more information, see Create a backup plan.

**Procedure**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. Click the **Replica Management** tab, click **Create Replica**, and configure the following
parameters.

| Parameter | Description |
|---|---|
| Backup Plan | Select a backup plan from the drop-down list. Data is backed up based on the configuration of the selected backup plan. |
| Replica Name | Enter a name for the replica task. |
| Description | Enter the description of the replica task. |

4. Click **Submit**.
5. After you submit the replica task, you can view the task status (Synchronizing, Healthy,
Failed, Canceled, Canceling, or Waiting), synchronization progress, and creation time in the task list.

#### 3.4.3 Import jobs

You can create import jobs to import data from Object Storage Service (OSS) to ApsaraStack Parallel File System (APFS).

**Limits**

A user can run only one import job at a time. At most three import jobs can be run concurrently on a global scale. The corresponding file system must be in the Available state.

**Create an import job**

**Prerequisites**

An APFS file system is created and is in the Available state. For more information, see Create an APFS file system. An OSS bucket is created.

**Procedure**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. Click the **Import Job** tab.
4. Click **Create Import Job** and configure the following parameters.

| Section | Parameter | Description |
|---|---|---|
| Basic Information | Import Name | Enter a name for the import job. |
|   | Description | Enter the description of the import job. |
|   | Target File System | Select the destination APFS file system from the drop-down list. |
|   | OSS Bucket | Select the OSS bucket where the source data is stored from the drop-down list. |
|   | File System Path | Enter a path in the APFS file system. Example: /target/path. |
|   | OSS Object Path | Enter the OSS path of the source data. Example: oss-bucket- name/oss-path. |
| Advanced Configuratio n | Bandwidth Limit | Specify the maximum bandwidth used for file transfer. Format: number + unit. Supported units: K (KB/s), M (MB/s), and G (GB/s). Example: 50M indicates that the upper limit is 50 MB/s. If you do not want to limit the bandwidth usage, enter off . If you leave this parameter empty, the default value 200M is used, which indicates that the upper limit is 200 MB/s. |
|   | Excluded Paths | The paths of files that you do not want to import in the OSS bucket. All files in the specified paths are not imported to APFS. Separate multiple paths with commas (,). Example: /tmp,/logs,/cache. |
|   | Filename Matching Pattern | Enter the extensions of files that you want to import. Only matching files are imported. Separate multiple file extensions with commas (,). Example: *.log,*.tmp,*.bak. |

**Manage import jobs**

1. Log in to the APFS console.
2. In the left-side navigation pane, click **Data Flow**.
3. Click the **Import Job** tab to manage import jobs.

| Operation | Description |
|---|---|

| View import jobs | Click the name of an import job in theJ ob Name column to view its details. Basic Information: displays the job ID, job name, file system ID, progress (%), replica size, and number of files. Progress Information: displays the synchronization progress (%), transfer speed, number of transferred files, and size (bytes). Storage Information: displays the file system path, OSS bucket, OSS path, and total size (bytes). |
|---|---|
| Cancel import jobs | You can cancel import jobs that are in the Synchronizing state. Click Cancel Task in the Actions column of the desired job. In the message that appears, confirm the information and click OK. |
| Delete import jobs | You can delete import jobs that are no longer needed. Note Files that have already been imported into APFS are not deleted. Click Delete Job in the Actions column of the desired job. In the message that appears, confirm the information and click OK. |

## 4 FAQ

This topic provides answers to frequently asked questions (FAQ) about ApsaraStack Parallel File System (APFS).

### 4.1 No inventory for sales

This topic describes solutions for the failure to create an ApsaraStack Parallel File System (APFS) file system due to insufficient inventory.

**Symptom**

When you create or scale up an APFS file system, the following exception message may appear.

**Solutions**

Solution 1: Decrease the capacity of the file system. Scenario 2: Modify the zone of the file system. Solution 3: Delete any redundant file system, contact the on-site O&M engineer to release disk space, and then create or scale up the file system again.
